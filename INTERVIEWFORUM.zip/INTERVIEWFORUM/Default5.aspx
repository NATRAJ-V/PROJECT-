﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Default5.aspx.cs" Inherits="Default5" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <meta charset="utf-8" />
    <title>Canvas Example</title>
    <script>
        function convertToImage() {
            // Get the canvas element
            var canvas = document.getElementById("canvas");

            // Get the data URL of the canvas content (PNG format)
            var imageData = canvas.toDataURL("images/png");

            // Send the data URL to the server via AJAX
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "Default5.aspx", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        console.log("Image saved successfully.");
                    } else {
                        console.error("Failed to save image.");
                    }
                }
            };
            xhr.send("imageData=" + encodeURIComponent(dataURL));
        }
    </script>
   
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            var canvas = document.getElementById("canvas");
            var ctx = canvas.getContext("2d");
            var isDrawing = false;

            canvas.addEventListener("mousedown", function (event) {
                isDrawing = true;
                ctx.beginPath();
                ctx.moveTo(event.clientX - canvas.offsetLeft, event.clientY - canvas.offsetTop);
            });

            canvas.addEventListener("mousemove", function (event) {
                if (isDrawing) {
                    ctx.lineTo(event.clientX - canvas.offsetLeft, event.clientY - canvas.offsetTop);
                    ctx.stroke();
                }
            });

            canvas.addEventListener("mouseup", function () {
                isDrawing = false;
            });

            canvas.addEventListener("mouseout", function () {
                isDrawing = false;
            });
        });

       
    </script>
    <script>
     function saveCanvasData() {
    // Capture canvas data and convert it to a data URL
    var canvas = document.getElementById("canvas");
    var imageData = canvas.toDataURL("images/png");

    // Send the data URL to the server via AJAX
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "Default5.aspx", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                console.log("Image saved successfully.");
            } else {
                console.error("Failed to save image.");
            }
        }
    };
    xhr.send("imageData=" + encodeURIComponent(imageData));
    </script>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <canvas id="canvas" width="400" height="200"  style="border: 1px solid black;"></canvas>
        </div>
        <button onclick="convertToImage()">Convert to Image</button>
        <asp:Button ID="Button1" runat="server" onclick="Button1_Click" Text="Button"  OnClientClick="saveCanvasData(); return false;" />
    </form>
</body>
</html>
