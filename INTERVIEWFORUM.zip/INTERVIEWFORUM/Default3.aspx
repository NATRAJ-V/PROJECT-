﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="Default3.aspx.cs" Inherits="Default3" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title></title>
     <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="styles.min.css"> <!-- remember to minify! -->
        <link rel="shortcut icon" href="./assets/favicon.ico" type="image/x-icon">
        <link rel="manifest" href="manifest.json">
        <script async src="https://cdn.jsdelivr.net/npm/pwacompat@2.0.8/pwacompat.min.js" integrity="sha384-uONtBTCBzHKF84F6XvyC8S0gL8HTkAPeCyBNvfLfsqHh+Kd6s/kaS4BdmNQ5ktp1" crossorigin="anonymous"></script>
        <!--codemirror-->
        <link rel="stylesheet" href="lib/codemirror.css">
        <script src="lib/codemirror.js"></script>
        <script src="mode/htmlmixed/htmlmixed.js"></script>
        <script src="mode/xml/xml.js"></script>
        <script src="mode/css/css.js"></script>
        <script src="mode/javascript/javascript.js"></script>
        <script src="edit/closebrackets.js"></script>
        <script src="edit/closetag.js"></script>
        <!--codemirror-->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

</head>
<body>
    <form id="form1" runat="server">
    <div>
    <header>
            <h1 id="title">PHP Online Interview And Job Selection Using Online Editor SYSTEM   <a href=Default.aspx>BACK</a></h1>
          <asp:Button   
            ID="Button1" runat="server"  
            Text="Capture" onclick="Button1_Click"  />  
        
        
        </header>

        <div class="container">
            <div id="code_area"></div>
            <iframe id="code_output"></iframe>
        </div>

        <footer>
            <a href="https://github.com/gughog/">Developed By Pentaxial Technologies</a>, 2019
        </footer>
        <script src="script.js"></script>
    </div>
    </form>
</body>
</html>
