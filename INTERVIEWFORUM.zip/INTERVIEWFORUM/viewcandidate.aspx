﻿<%@ Page Language="C#" MasterPageFile="~/admin.master" AutoEventWireup="true" CodeFile="viewcandidate.aspx.cs" Inherits="viewcandidate" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
<script language="javascript" type="text/javascript">
     function accept(id)
    {
    location.href='viewcandidate.aspx?id='+id;
    }
     function sendmail(id1)
    {
    location.href='viewcandidate.aspx?id1='+id1;
    }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
<div id = "dvGrid" style ="padding:10px;width:100%; overflow:scroll; height:100%">
  <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" 
            OnPageIndexChanging="GridView1_PageIndexChanging" AllowPaging="True" 
       PageSize="5" onselectedindexchanged="GridView1_SelectedIndexChanged1" 
              Height="98px" Font-Bold="True"  HorizontalAlign="Center" 
            CellPadding="4" 
         style="width:933px; " 
                ForeColor="Black" BackColor="#CCCCCC" BorderColor="#999999" 
             BorderStyle="Solid" BorderWidth="3px" CellSpacing="2">
            <RowStyle HorizontalAlign="Center" BackColor="White"/>
                <Columns>
                  <asp:BoundField DataField="id" HeaderText="Sno" />
                  <asp:BoundField DataField="username" HeaderText="Candidate Name"/>
                  <asp:BoundField DataField="address" HeaderText="Address"/>
                  <asp:BoundField DataField="phoneno" HeaderText="Phone No"/>
                  <asp:BoundField DataField="emailid" HeaderText="Email ID"/>
                  <asp:BoundField DataField="qualification" HeaderText="Qualification"/>
                  <asp:BoundField DataField="postname" HeaderText="Postname"/>
                  <asp:BoundField DataField="expfresher" HeaderText="Exp/Fresher"/>
                  <asp:TemplateField HeaderText="">
                  <ItemTemplate>
                    <a href="javascript:accept('<%# DataBinder.Eval(Container.DataItem,"id")%>')" ><h3 style="color:black">
                        Download & Verify</h3></a>
                      </ItemTemplate>
                  </asp:TemplateField>
                   <asp:TemplateField HeaderText="">
                  <ItemTemplate>
                    <a href="javascript:sendmail('<%# DataBinder.Eval(Container.DataItem,"id")%>')" ><h3 style="color:black">
                        Send Mail</h3></a>
                      </ItemTemplate>
                  </asp:TemplateField>
                 </Columns>
            <FooterStyle BackColor="#CCCCCC" />
            <PagerStyle ForeColor="Black" HorizontalAlign="Left" BackColor="#CCCCCC" />
            <SelectedRowStyle BorderColor="Orange" BackColor="#000099" Font-Bold="True" 
                 ForeColor="White"  />
            <HeaderStyle BorderColor="Orange"  HorizontalAlign="Center" BackColor="Black" 
                Font-Bold="True" ForeColor="White" />
        </asp:GridView> 
        </div>
</asp:Content>

