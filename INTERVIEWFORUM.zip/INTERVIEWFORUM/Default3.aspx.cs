﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging; 

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public static void Capture(string CapturedFilePath)
    {
        Bitmap bitmap = new Bitmap
      (Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);

        Graphics graphics = Graphics.FromImage(bitmap as System.Drawing.Image);
        graphics.CopyFromScreen(25, 25, 25, 25, bitmap.Size);

        bitmap.Save(CapturedFilePath, ImageFormat.Bmp);
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Capture("D:/ScreenShot.bmp");//path to Save Captured files  
    } 

}
