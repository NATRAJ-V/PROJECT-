﻿<%@ Page Language="C#" MasterPageFile="~/admin.master" AutoEventWireup="true" CodeFile="addquestion.aspx.cs" Inherits="addquestion" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
<style type="text/css">
*,
*:before,
*:after {
   box-sizing: border-box;
}
fieldset {
 border: 1px solid #c6c7cc;
  border-radius: 6px;
  margin: 0;
  padding: 0;
}
 .btn {
  background: linear-gradient(white, white);
  border:1;
  color:Blue;
  cursor: pointer;
  font-weight: bold;
  float:none;
  padding: 8px 16px;
  align:center;
}
</style>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
<fieldset style="width:300px;">
        <legend style="color:Blue; font-size:15px;">TASK 1 Question</legend>
           <table style="color:Black; font-size:15px; padding:1 1 2 2">
             <tr>
             <td>
           Domain Name:  
           </td>
             <td>
<asp:DropDownList ID="DropDownList2" runat="server">
                     <asp:ListItem>--Select--</asp:ListItem>
                     <asp:ListItem>ASP.NET</asp:ListItem>
                     <asp:ListItem>PHP</asp:ListItem>
                     <asp:ListItem>WORDPRESS</asp:ListItem>
                     <asp:ListItem>ANDROID</asp:ListItem>
                 </asp:DropDownList></td>
            <td>
                &nbsp;</td>
             </tr>
             <tr>
             <td>
            Task Name: 
             </td>
             <td>
            <asp:TextBox ID="TextBox2" runat="server" ValidationGroup="admin"></asp:TextBox> 
            </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator5" runat="server" 
                    ErrorMessage="*" ControlToValidate="TextBox2" ValidationGroup="admin"></asp:RequiredFieldValidator>
            </td>
            </tr>
             <tr>
             <td>
            Task ID: 
             </td>
             <td>
            <asp:TextBox ID="TextBox3" runat="server" ValidationGroup="admin"></asp:TextBox> 
            </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" 
                    ErrorMessage="*" ControlToValidate="TextBox3" ValidationGroup="admin"></asp:RequiredFieldValidator>
            </td>
            </tr>
            <tr>
             <td>
             Upload File:  
             </td>
             <td>
                 <asp:FileUpload ID="FileUpload1" runat="server" ValidationGroup="admin"/>
             </td>
              <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" 
                    ErrorMessage="*" ControlToValidate="FileUpload1" ValidationGroup="admin">
                    </asp:RequiredFieldValidator>
            </td>
             </tr>
             </table>
          </fieldset>
          <fieldset style="width:300px;">
            <asp:Button ID="Button1" runat="server" Text="Upload" BackColor="White" 
                  ForeColor="Blue" CssClass="btn" onclick="Button1_Click"/>
                   <asp:Button ID="Button2" runat="server" Text="View Post" BackColor="White" 
                  ForeColor="Blue" CssClass="btn" onclick="Button2_Click"/>
        </fieldset>
        <br /> <br />
         <br /> <br />
         <br /> <br />
         <br /> <br />
         <br /> <br />
          <br /> <br />
</asp:Content>

