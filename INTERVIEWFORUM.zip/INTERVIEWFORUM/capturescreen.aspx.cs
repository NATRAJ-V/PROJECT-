﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.IO;
using System.Data;
public partial class capturescreen : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bin();
            accept();
            sendmail();
            rejectmail();
        }
    }
    public void bin()
    {
        Class1 getcon = new Class1();
        SqlConnection con1 = getcon.connect();
        SqlCommand cmd2 = new SqlCommand("select * from dbo.editortask", con1);
        SqlDataAdapter da = new SqlDataAdapter(cmd2);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Not found');</script>");
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        bin();
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
    }
    public void accept()
    {
        if (Request.QueryString["id"] != null)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("select * from editortask where id='" + Request.QueryString["id"].ToString() + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["captureimg"] = dr["captureimg"].ToString();
                string filename = "~/Screen/" + Session["captureimg"].ToString();
                Response.ContentType = "application/octet-stream";
                Response.AppendHeader("Content-Disposition", "attachment;filename=" + filename);
                string aaa = Server.MapPath(filename);
                Response.TransmitFile(Server.MapPath(filename));
                Response.End();
            }
        }
    }
    public void sendmail()
    {
        if (Request.QueryString["id1"] != null)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("select * from editortask where id='" + Request.QueryString["id1"].ToString() + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["candname"] = dr["candname"].ToString();
                                Session["candemailid"] = dr["candemailid"].ToString();
                Session["id"] = dr["id"].ToString();
                Class1 getcon1 = new Class1();
                SqlConnection con1 = getcon1.connect();
                SqlCommand cmd1 = new SqlCommand("update editortask set intstatus='accept' where id='" + Request.QueryString["id1"].ToString() + "'", con1);
                cmd1.ExecuteNonQuery();
                MailMessage msg = new MailMessage(new MailAddress("noreplymailing22@gmail.com"), new MailAddress(Session["candemailid"].ToString()));
                msg.Subject = "Status Of Interview Task ";
                msg.IsBodyHtml = true;
                msg.Body = "Candidate Name: " + Session["candname"].ToString() + "<br/>" + "Your Are  Eligible to Attend Task.... go And Attend Second Task.";
                System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("noreplymailing22@gmail.com", "ipudbyifzmcsjyhk");
                SmtpClient smclient = new SmtpClient();
                smclient.EnableSsl = true;
                smclient.UseDefaultCredentials = false;
                smclient.Credentials = nwcred;
                smclient.Host = "smtp.gmail.com";
                smclient.Port = 587;
                smclient.Send(msg);
                ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Status Updated Successfully and Send Mail!!!');</script>");
                bin();
            }
        }
    }

    public void rejectmail()
    {
        if (Request.QueryString["id2"] != null)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("select * from editortask where id='" + Request.QueryString["id2"].ToString() + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["candname"] = dr["candname"].ToString();
                
                Session["candemailid"] = dr["candemailid"].ToString();
                Session["id"] = dr["id"].ToString();
                Class1 getcon1 = new Class1();
                SqlConnection con1 = getcon1.connect();
                SqlCommand cmd1 = new SqlCommand("update editortask set intstatus='reject' where id='" + Request.QueryString["id2"].ToString() + "'", con1);
                cmd1.ExecuteNonQuery();
                MailMessage msg = new MailMessage(new MailAddress("noreplymailing22@gmail.com"), new MailAddress(Session["candemailid"].ToString()));
                msg.Subject = "Status Of Interview Task ";
                msg.IsBodyHtml = true;
                msg.Body = "Candidate Name: " + Session["candname"].ToString() + "<br/>" + "Thanks  For Your Attend The Interview .Well Learn And Come Back.";
                System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("noreplymailing22@gmail.com", "ipudbyifzmcsjyhk");
                SmtpClient smclient = new SmtpClient();
                smclient.EnableSsl = true;
                smclient.UseDefaultCredentials = false;
                smclient.Credentials = nwcred;
                smclient.Host = "smtp.gmail.com";
                smclient.Port = 587;
                smclient.Send(msg);
                ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Status Updated!');</script>");
                bin();
            }
        }
    }


}
