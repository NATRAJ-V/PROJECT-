﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Net;
using System.Net.Mail;
public partial class viewselection : System.Web.UI.Page
{
    SqlDataAdapter dadapter;
    DataSet dset;
    DataSet DS = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Class1 getcon1 = new Class1();
            SqlConnection con1 = getcon1.connect();
            string sql1 = "select distinct username from tasksecondques";
            if (!IsPostBack)
            {
                dadapter = new SqlDataAdapter(sql1, con1);
                dset = new DataSet();
                dadapter.Fill(dset);
                DropDownList1.DataSource = dset.Tables[0];
                DropDownList1.DataTextField = "username";
                DropDownList1.DataValueField = "username";
                DropDownList1.DataBind();
            }
            DropDownList1.Items.Add("--Select--");
            DropDownList1.Items.FindByValue("--Select--").Selected = true;
        }
    }
    public void displ()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("select * from candidatereg where username='" + DropDownList1.SelectedValue + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            TextBox2.Text = dr["emailid"].ToString();
        }
    }
    public void disp()
    {

        Class1 getcon1 = new Class1();
        SqlConnection con1 = getcon1.connect();
        string sql1 = "select distinct domainname from tasksecondques where username='" + DropDownList1.SelectedItem.Text + "'";
        dadapter = new SqlDataAdapter(sql1, con1);
        dset = new DataSet();
        dadapter.Fill(dset);
        DropDownList2.DataSource = dset.Tables[0];
        DropDownList2.DataTextField = "domainname";
        DropDownList2.DataValueField = "domainname";
        DropDownList2.DataBind();
        DropDownList2.Items.Add("--Select--");
        DropDownList2.Items.FindByValue("--Select--").Selected = true;

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        disp();
        displ();
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("select sum(cast(mark As int)) As Mark from tasksecondques where username='"+DropDownList1.SelectedValue+"' and domainname='"+DropDownList2.SelectedValue+"'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            TextBox1.Text = dr["Mark"].ToString();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(TextBox1.Text) >= 35)
        {
            MailMessage msg = new MailMessage(new MailAddress("customerdotnet@gmail.com"), new MailAddress(TextBox2.Text));
            msg.Subject = "Interview Second Task Result";
            msg.IsBodyHtml = true;
            msg.Body = "Hi " + Session["username"].ToString() + "<br/>" + "Congrats You are Selected!! Come and Get Your Appointment Order";
            // msg.Attachments.Add(new Attachment(fileName));
            System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("customerdotnet@gmail.com", "dotnet123");
            SmtpClient smclient = new SmtpClient();
            smclient.EnableSsl = true;
            smclient.UseDefaultCredentials = false;
            smclient.Credentials = nwcred;
            smclient.Host = "smtp.gmail.com";
            smclient.Port = 587;
            smclient.Send(msg);
            ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Mail Sent Successfully');</script>");

        }
        else 
         if (Convert.ToInt32(TextBox1.Text) < 35)
        {
            MailMessage msg = new MailMessage(new MailAddress("customerdotnet@gmail.com"), new MailAddress(TextBox2.Text));
            msg.Subject = "Interview Second Task Result";
            msg.IsBodyHtml = true;
            msg.Body = "Hi " + Session["username"].ToString() + "<br/>" + "You are not Qualified!!";
            // msg.Attachments.Add(new Attachment(fileName));
            System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("customerdotnet@gmail.com", "dotnet123");
            SmtpClient smclient = new SmtpClient();
            smclient.EnableSsl = true;
            smclient.UseDefaultCredentials = false;
            smclient.Credentials = nwcred;
            smclient.Host = "smtp.gmail.com";
            smclient.Port = 587;
            smclient.Send(msg);
            ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Mail Sent Successfully');</script>");

        }
    }
}
