﻿
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public partial class addquestion : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Class1 getcon1 = new Class1();
        SqlConnection con1 = getcon1.connect();
        SqlCommand cmd1 = new SqlCommand("select * from firsttaskques where domainname='" + DropDownList2.SelectedItem.Text + "' and taskid='" + TextBox3.Text + "'", con1);
        SqlDataReader dr1 = cmd1.ExecuteReader();
        if (dr1.Read())
        {

            ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Already Exists!!!!');</script>");

         }
        else
        {
            String aa = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);
            string input = Server.MapPath("~/questions/") + aa;
            FileUpload1.SaveAs(input);
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("insert into firsttaskques values('" + DropDownList2.SelectedItem.Text+ "','" + TextBox2.Text + "','" + aa + "','" + TextBox3.Text + "')", con);
            cmd.ExecuteNonQuery();
            ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('First Task Question Details Saved Successfully!!!!');</script>");


           
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("viewfirsttask.aspx");
    }
}
