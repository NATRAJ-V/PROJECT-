﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;
using System.Data.SqlClient;
public partial class taskform : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    public static void Capture(string CapturedFilePath)
    {
        Bitmap bitmap = new Bitmap
            
      (Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);

        Graphics graphics = Graphics.FromImage(bitmap as System.Drawing.Image);
        graphics.CopyFromScreen(25, 25, 25, 25, bitmap.Size);

        bitmap.Save(CapturedFilePath, ImageFormat.Bmp);
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Capture("D:/dotnetprojects/INTERVIEWFORUM/Screen/"+Session["taskid"].ToString()+".bmp");//path to Save Captured files  

        string a = Session["taskid"].ToString() + ".bmp";
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("update editortask set captureimg='"+a+"',status='Finished' where id='"+ Session["taskid"].ToString()+"'", con);
        cmd.ExecuteNonQuery();
        ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Editor Task Updated Successfully!Click TO Back For Next Process');</script>");
        Button1.Enabled = false;

    }
}
