﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.IO;
public partial class taskfirstresult : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            bin();
            accept();
            sendmail();
            download();
        }
    }
    public void bin()
    {
        Class1 getcon = new Class1();
        SqlConnection con1 = getcon.connect();
        SqlCommand cmd2 = new SqlCommand("select * from firsttask where status='completed'", con1);
        SqlDataAdapter da = new SqlDataAdapter(cmd2);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Not found');</script>");
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        bin();
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
    }
    public void accept()
    {
        if (Request.QueryString["id"] != null)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("select * from firsttask where id='" + Request.QueryString["id"].ToString() + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["uploadfile"] = dr["taskans"].ToString();
                string filename = "~/taskans/" + Session["uploadfile"].ToString();
                Response.ContentType = "application/octet-stream";
                Response.AppendHeader("Content-Disposition", "attachment;filename=" + filename);
                string aaa = Server.MapPath(filename);
                Response.TransmitFile(Server.MapPath(filename));
                Response.End();
            }
        }
    }
    public void download()
    {
        if (Request.QueryString["taskid"] != null)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("select * from firsttaskques where taskid='" + Request.QueryString["taskid"].ToString() + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["uploadfile"] = dr["uploadtask"].ToString();
                string filename = "~/questions/" + Session["uploadfile"].ToString();
                Response.ContentType = "application/octet-stream";
                Response.AppendHeader("Content-Disposition", "attachment;filename=" + filename);
                string aaa = Server.MapPath(filename);
                Response.TransmitFile(Server.MapPath(filename));
                Response.End();
            }
        }
    }
    public void sendmail()
    {
        if (Request.QueryString["id1"] != null)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("select * from firsttask where id='" + Request.QueryString["id1"].ToString() + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["username"] = dr["username"].ToString();
            
                Session["emailid111"] = dr["emailid"].ToString();
                Session["id"] = dr["id"].ToString();
                Class1 getcon1 = new Class1();
                SqlConnection con1 = getcon1.connect();
                SqlCommand cmd1 = new SqlCommand("update firsttask set status='verified' where id='" + Session["id"].ToString() + "'", con1);
                cmd1.ExecuteNonQuery();
                MailMessage msg = new MailMessage(new MailAddress("noreplymailing22@gmail.com"), new MailAddress(Session["emailid111"].ToString()));
                msg.Subject = "Final Task Result ";
                msg.IsBodyHtml = true;
                msg.Body = "Username: " + Session["username"].ToString() + "<br/>" + "Congrats.. You Selected For All Rounds Wait and meet Hr Technical..";
                System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("noreplymailing22@gmail.com", "ipudbyifzmcsjyhk");
                SmtpClient smclient = new SmtpClient();
                smclient.EnableSsl = true;
                smclient.UseDefaultCredentials = false;
                smclient.Credentials = nwcred;
                smclient.Host = "smtp.gmail.com";
                smclient.Port = 587;
                smclient.Send(msg);
                ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Mail Sent Successfully!!!');</script>");
                bin();
            }
        }
    }

    public void reject()
    {

        if (Request.QueryString["id2"] != null)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("select * from firsttask where id='" + Request.QueryString["id2"].ToString() + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["username"] = dr["username"].ToString();

                Session["emailid22"] = dr["emailid"].ToString();
                Session["id"] = dr["id"].ToString();
                Class1 getcon1 = new Class1();
                SqlConnection con1 = getcon1.connect();
                SqlCommand cmd1 = new SqlCommand("update firsttask set status='Rejected' where id='" + Request.QueryString["id1"].ToString() + "'", con1);
                cmd1.ExecuteNonQuery();
                MailMessage msg = new MailMessage(new MailAddress("noreplymailing22@gmail.com"), new MailAddress(Session["emailid22"].ToString()));
                msg.Subject = "Final Task Result ";
                msg.IsBodyHtml = true;
                msg.Body = "Username: " + Session["username"].ToString() + "<br/>" + "Thanks For Attend The Interview.Well Learn And BACK..";
                System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("noreplymailing22@gmail.com", "ipudbyifzmcsjyhk");
                SmtpClient smclient = new SmtpClient();
                smclient.EnableSsl = true;
                smclient.UseDefaultCredentials = false;
                smclient.Credentials = nwcred;
                smclient.Host = "smtp.gmail.com";
                smclient.Port = 587;
                smclient.Send(msg);
                ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Mail Sent Successfully!!!');</script>");
                bin();
            }
        }
    }
}
