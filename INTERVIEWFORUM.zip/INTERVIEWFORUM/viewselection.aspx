﻿<%@ Page Language="C#" MasterPageFile="~/admin.master" AutoEventWireup="true" CodeFile="viewselection.aspx.cs" Inherits="viewselection" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
<style type="text/css">
*,
*:before,
*:after {
   box-sizing: border-box;
}
fieldset {
 border: 1px solid #c6c7cc;
  border-radius: 6px;
  margin: 0;
  padding: 0;
}
 .btn {
  background: linear-gradient(white, white);
  border:1;
  color:Blue;
  cursor: pointer;
  font-weight: bold;
  float:none;
  padding: 8px 16px;
  align:center;
}
</style>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
<fieldset style="width:300px;">
        <legend style="color:Blue; font-size:15px;"></legend>
           <table style="color:Black; font-size:15px; padding:1 1 2 2">
            <tr>
             <td>
                 User Name:  </td>
             <td>
                 <asp:DropDownList ID="DropDownList1" runat="server" ValidationGroup="admin" 
                     Height="40%" AutoPostBack="True" 
                     onselectedindexchanged="DropDownList1_SelectedIndexChanged">
                 </asp:DropDownList>
           </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" 
                    ErrorMessage="*" ControlToValidate="DropDownList1" ValidationGroup="admin"></asp:RequiredFieldValidator>
            </td>
             </tr>
             <tr>
             <td>
                 Email ID:  </td>
             <td>
                       <asp:TextBox ID="TextBox2" runat="server" Height="40%"></asp:TextBox>
         
           </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" 
                    ErrorMessage="*" ControlToValidate="TextBox2" ValidationGroup="admin"></asp:RequiredFieldValidator>
            </td>
             </tr>
             <tr>
             <td>
                 Domain Name:  </td>
             <td>
                 <asp:DropDownList ID="DropDownList2" runat="server" ValidationGroup="admin" 
                     Height="40%" AutoPostBack="True" onselectedindexchanged="DropDownList2_SelectedIndexChanged">
                 </asp:DropDownList>
           </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator7" runat="server" 
                    ErrorMessage="*" ControlToValidate="DropDownList2" ValidationGroup="admin"></asp:RequiredFieldValidator>
            </td>
             </tr>
              <tr>
             <td>
                 Mark Scored:  </td>
             <td>
                 <asp:TextBox ID="TextBox1" runat="server" Height="40%"></asp:TextBox>
           </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" 
                    ErrorMessage="*" ControlToValidate="TextBox1" ValidationGroup="admin"></asp:RequiredFieldValidator>
            </td>
             </tr>
             <tr>
             <td>
             
                 <asp:Button ID="Button1" runat="server" Text="Submit" onclick="Button1_Click" />
             </td>
             </tr>
             </table>
</asp:Content>

