﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
/// <summary>
/// Summary description for Class1
/// </summary>
public class Class1
{
	public Class1()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public SqlConnection connect()
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-BVQNVSJ\\SQLEXPRESS;Initial Catalog=interviewprocess;Integrated Security=true;");
        con.Open();
        return con;
    }
}
