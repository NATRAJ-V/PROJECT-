﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class editorforum : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["email"] != null)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("select * from editortask where candemailid='" + Request.QueryString["email"].ToString() + "' and status='started'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Label2.Text = dr["taskcontent"].ToString();
                Session["taskid"] = dr["id"].ToString();
                //Session["candname"] = dr["candname"].ToString();

                Label2.Visible = true;
                LinkButton1.Visible = true;
            }
        }
        else
        {
            Label2.Visible = false;
            LinkButton1.Visible = false;
            Label1.Text = "Waiting For Approvel";
        }
        
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("taskform.aspx");
    }
}
