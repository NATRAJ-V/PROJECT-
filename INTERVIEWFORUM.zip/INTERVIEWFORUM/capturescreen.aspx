﻿<%@ Page Title="" Language="C#" MasterPageFile="~/admin.master" AutoEventWireup="true" CodeFile="capturescreen.aspx.cs" Inherits="capturescreen" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
<script language="javascript" type="text/javascript">
     function accept(id)
    {
    location.href='capturescreen.aspx?id='+id;
    }
     function accept1(id1)
    {
    location.href='capturescreen.aspx?id1='+id1;
}
function reject(id2) {
    location.href = 'capturescreen.aspx?id2=' + id2;
}
    </script>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
<div id = "dvGrid" style ="padding:10px;width:100%; overflow:scroll; height:100%">
  <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" 
            OnPageIndexChanging="GridView1_PageIndexChanging" AllowPaging="True" 
       PageSize="5" onselectedindexchanged="GridView1_SelectedIndexChanged1" 
              Height="98px" Font-Bold="True"  HorizontalAlign="Center" 
            CellPadding="4" 
         style="width:933px; " 
                ForeColor="Black" BackColor="#CCCCCC" BorderColor="#999999" 
             BorderStyle="Solid" BorderWidth="3px" CellSpacing="2">
            <RowStyle HorizontalAlign="Center" BackColor="White"/>
                <Columns>
                  <asp:BoundField DataField="id" HeaderText="Sno" />
                  <asp:BoundField DataField="candname" HeaderText="Candidate Name"/>
                  <asp:BoundField DataField="taskfile" HeaderText="taskfile"/>
                  <asp:BoundField DataField="dateofaccess" HeaderText="Date"/>
                  <asp:BoundField DataField="status" HeaderText="status"/>
                  
                  <asp:BoundField DataField="intstatus" HeaderText="intstatus"/>
                  
                  <asp:TemplateField HeaderText="Capture Screen">
                  <ItemTemplate>
                    <a href="javascript:accept('<%# DataBinder.Eval(Container.DataItem,"id")%>')" ><h3 style="color:black">
                        Download</h3></a>
                      </ItemTemplate>
                  </asp:TemplateField>
                  <asp:TemplateField HeaderText="Accept">
                  <ItemTemplate>
                    <a href="javascript:accept1('<%# DataBinder.Eval(Container.DataItem,"id")%>')" ><h3 style="color:black">
                        Accept</h3></a>
                      </ItemTemplate>
                  </asp:TemplateField>
                  
                  <asp:TemplateField HeaderText="Reject">
                  <ItemTemplate>
                    <a href="javascript:reject('<%# DataBinder.Eval(Container.DataItem,"id")%>')" ><h3 style="color:black">
                        Reject</h3></a>
                      </ItemTemplate>
                  </asp:TemplateField>
                  
                  </Columns>
            <FooterStyle BackColor="#CCCCCC" />
            <PagerStyle ForeColor="Black" HorizontalAlign="Left" BackColor="#CCCCCC" />
            <SelectedRowStyle BorderColor="Orange" BackColor="#000099" Font-Bold="True" 
                 ForeColor="White"  />
            <HeaderStyle BorderColor="Orange"  HorizontalAlign="Center" BackColor="Black" 
                Font-Bold="True" ForeColor="White" />
        </asp:GridView> 
        </div>

</asp:Content>

