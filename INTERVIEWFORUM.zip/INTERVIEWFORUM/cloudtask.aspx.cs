﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class cloudtask : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("select * from editortask where candemailid='" + Session["e-mailid"].ToString() + "' and intstatus='accept'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Label1.Text = "First Task Completed Successfully GO And Attend Second Task";
                Session["taskid"] = dr["id"].ToString();
                //Session["candname"] = dr["candname"].ToString();

                Label2.Visible = true;
                LinkButton1.Visible = true;
            }
       
        else
        {
            Label2.Visible = false;
            LinkButton1.Visible = false;
            Label1.Text = "Thanks  For Your Attend The Interview .Well Learn And Come Back";
        }

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("attendtask.aspx");
    }

}
