﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;
using System.Data.SqlClient;

public partial class Default5 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    public static void Capture(string CapturedFilePath)
    {
        Bitmap bitmap = new Bitmap

      (Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);

        Graphics graphics = Graphics.FromImage(bitmap as System.Drawing.Image);
        graphics.CopyFromScreen(25, 25, 25, 25, bitmap.Size);

        bitmap.Save(CapturedFilePath, ImageFormat.Bmp);
    }

  
    //[HttpPost]
    //public ActionResult SaveCanvasData(string imageData)
    //{
    //    // Process imageData in C#
    //    // Example: Decode data URL to extract image data
    //    byte[] imageBytes = Convert.FromBase64String(imageData.Split(',')[1]);

    //    // Further processing, such as saving image data to a file or database
    //    // Example:
    //    string imagePath = Server.MapPath("~/images/canvas_image.png");
    //    System.IO.File.WriteAllBytes(imagePath, imageBytes);

    //    // Return success response
    //    Response.Write("Image saved successfully.");
    //}
    protected void Button1_Click(object sender, EventArgs e)
    {
        Capture("D:/dotnetprojects/INTERVIEWFORUM/Screen/" + Session["taskid"].ToString() + ".bmp");//path to Save Captured files  

        string a = "sample" + ".bmp";
       
 //       string imageData = Request.Form["imageData"];

 //       // Decode the data URL to get the image data
 //       byte[] imageBytes = Convert.FromBase64String(imageData.Split(',')[1]);

 //       // Save the image to a file on the server
 //       string imagePath = Server.MapPath("~/images/canvas_image.png");
 //       File.WriteAllBytes(imagePath, imageBytes);

 //       // Send a success response back to the client
 //       Response.StatusCode = 200;
 //       Response.Write("Image saved successfully.");
 //       Response.End();
 //////string a = canvas.InnerText;
 ////       Response.Write(a);
 //       string imageData = Request.Form["imageData"];
 //       if (imageData != null)
 //       {
 //           // Proceed with processing the imageData

 //           // Decode the data URL to get the image data
 //           byte[] imageBytes = Convert.FromBase64String(imageData.Split(',')[1]);

 //           // Save the image to a file on the server
 //           string imagePath = Server.MapPath("~/image/canvas_image.png"); // Change the path as needed
 //           File.WriteAllBytes(imagePath, imageBytes);

 //           // Optionally, you can send a response back to the client
 //           Response.StatusCode = 200;
 //           Response.Write("Image saved successfully.");
 //           Response.End();

 //       }
 //       else
 //       {
 //           Response.Write("error");
 //       }
    }
}