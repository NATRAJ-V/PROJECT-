﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
public partial class Default4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://maps.google.com/maps?q=" +TextBox1.Text+" ");


    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        WebClient client = new WebClient();
        string strmsg = "jjjjjjjjjjjjjjjjjjjjjjjjj";
        //string baseurl = "http://pentax.smsblaster.in/httpapi/httpapi?token=188710f6e46b6f05432047a98c5f5d3e&sender=PENTAX&number=9940774418&route=2&type=1&sms=strmsg";
        string baseurl = "http://pentax.smsblaster.in/httpapi/httpapi?token=188710f6e46b6f05432047a98c5f5d3e&sender=PENTAX&number=9940774418&route=2&type=1&sms=confirm";

        Stream data = client.OpenRead(baseurl);
        StreamReader reader = new StreamReader(data);
        string s = reader.ReadToEnd();
        data.Close();
        reader.Close();
    }
}
