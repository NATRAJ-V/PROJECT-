﻿<%@ Page Title="" Language="C#" MasterPageFile="~/admin.master" AutoEventWireup="true" CodeFile="sendalert.aspx.cs" Inherits="sendalert" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
<script language="javascript" type="text/javascript">
     function accept(id)
    {
    location.href='sendalert.aspx?id='+id;
    }
     function sendmail(id1)
    {
        location.href = 'sendalert.aspx?id1=' + id1;
    }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
<div id = "dvGrid" style ="padding:10px;width:100%; overflow:scroll; height:100%">
        
        
        
        
  <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" 
            OnPageIndexChanging="GridView1_PageIndexChanging" AllowPaging="True" 
       PageSize="5" onselectedindexchanged="GridView1_SelectedIndexChanged1" 
              Height="98px" Font-Bold="True"  HorizontalAlign="Center" 
            CellPadding="4" 
         style="width:933px; " 
                ForeColor="Black" BackColor="#CCCCCC" BorderColor="#999999" 
             BorderStyle="Solid" BorderWidth="3px" CellSpacing="2">
            <RowStyle HorizontalAlign="Center" BackColor="White"/>
                <Columns>
                  <asp:BoundField DataField="id" HeaderText="Sno" />
                  <asp:BoundField DataField="username" HeaderText="Candidate Name"/>
                
                  <asp:BoundField DataField="qualification" HeaderText="Qualification"/>
                  <asp:BoundField DataField="postname" HeaderText="Postname"/>
                  <asp:BoundField DataField="expfresher" HeaderText="Exp/Fresher"/>
                  <asp:TemplateField HeaderText="">
                  <ItemTemplate>
                    <a href="javascript:sendmail('<%# DataBinder.Eval(Container.DataItem,"id")%>')" ><h3 style="color:black">
                      Send Task</h3></a>
                      </ItemTemplate>
                  </asp:TemplateField>
                   
                 </Columns>
            <FooterStyle BackColor="#CCCCCC" />
            <PagerStyle ForeColor="Black" HorizontalAlign="Left" BackColor="#CCCCCC" />
            <SelectedRowStyle BorderColor="Orange" BackColor="#000099" Font-Bold="True" 
                 ForeColor="White"  />
            <HeaderStyle BorderColor="Orange"  HorizontalAlign="Center" BackColor="Black" 
                Font-Bold="True" ForeColor="White" />
        </asp:GridView> 
        </div>
        <table>
        <tr>
        <td>
        Candidate Name
        </td><td>
            <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox>
        </td>
        </tr>
        <tr>
        <td>
        Email Id
        </td>
        <td>
            <asp:TextBox ID="TextBox2" runat="server"></asp:TextBox>
        </td>
        </tr>
        <tr>
        <td>
        Select WebDesigning Task
        </td>
        <td>
            <asp:DropDownList ID="DropDownList1" runat="server" AutoPostBack="True" 
                onselectedindexchanged="DropDownList1_SelectedIndexChanged">
            </asp:DropDownList>
        </td>
        </tr>
        <tr>
        <td>Task Content</td>
        <td>
            <asp:TextBox ID="TextBox3" runat="server" Height="36px" TextMode="MultiLine" 
                Width="173px"></asp:TextBox></td>
        </tr>
        <tr>
        <td>
            <asp:Button ID="Button1" runat="server" Text="Send" onclick="Button1_Click" />
        </td>
        <td>
            <asp:Button ID="Button2" runat="server" Text="Cancel" />
        </td>
        </tr>
        </table>
</asp:Content>

