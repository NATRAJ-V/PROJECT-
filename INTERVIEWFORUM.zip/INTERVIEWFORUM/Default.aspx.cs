﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

   
    protected void Button3_Click(object sender, EventArgs e)
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("select * from candidatereg where username='" + TextBox2.Text + "' and password='" + TextBox8.Text + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Session["username"] = TextBox2.Text;
            Session["e-mailid"] = dr["emailid"].ToString();
            TextBox2.Text = dr["password"].ToString();
            Response.Redirect("candhome.aspx");
        }
        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Invalid User');</script>");

        }

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("default.aspx");
    }

    public static string CreateRandomPassword2(int PasswordLength)
    {
        string _allowedChars = "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ@#@%";
        Random randNum = new Random();
        char[] chars = new char[PasswordLength];
        int allowedCharCount = _allowedChars.Length;
        for (int i = 0; i < PasswordLength; i++)
        {
            chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
        }
        return new string(chars);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        String aa1 = CreateRandomPassword2(12);
        String aa = System.IO.Path.GetFileName(FileUpload1.PostedFile.FileName);
        string input = Server.MapPath("~/uploadresume/") + aa;
        FileUpload1.SaveAs(input);
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("insert into candidatereg values('" + TextBox1.Text + "','" + aa1 + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + DropDownList1.SelectedValue + "','register','" + DateTime.Now.ToString("dd/MM/yyyy") + "','" + TextBox7.Text + "','" + aa + "')", con);
        cmd.ExecuteNonQuery();
        ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Candidate Register Successfully!!!!');</script>");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
       
    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
}
