﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.IO;
using System.Data;
using System.IO;
using System.Text;
public partial class sendalert : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bin();
            
            sendmail();
        }
    }
    public void dis()
    {
        DropDownList1.Items.Clear();
        Session["path"] = "D:/dotnetprojects/INTERVIEWFORUM/TFiles";
      
        DirectoryInfo di = new DirectoryInfo(Session["path"].ToString());
        FileInfo[] rgFiles = di.GetFiles("*.*");

        DropDownList1.Items.Insert(0, "");

        foreach (FileInfo fi in rgFiles)
        {
            DropDownList1.Items.Add(fi.Name);

        }


    }
    public void bin()
    {
        Class1 getcon = new Class1();
        SqlConnection con1 = getcon.connect();
        SqlCommand cmd2 = new SqlCommand("select * from candidatereg", con1);
        SqlDataAdapter da = new SqlDataAdapter(cmd2);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Not found');</script>");
        }
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        bin();
    }
    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
    }
    
    public void sendmail()
    {
        if (Request.QueryString["id1"] != null)
        {
            Class1 getcon = new Class1();
            SqlConnection con = getcon.connect();
            SqlCommand cmd = new SqlCommand("select * from candidatereg where id='" + Request.QueryString["id1"].ToString() + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
               TextBox1.Text = dr["username"].ToString();
                Session["password"] = dr["password"].ToString();
                TextBox2.Text = dr["emailid"].ToString();
                Session["id"] = dr["id"].ToString();
                if (!IsPostBack)
                {
                    dis();
                }
                //Class1 getcon1 = new Class1();
                //SqlConnection con1 = getcon1.connect();
                //SqlCommand cmd1 = new SqlCommand("update candidatereg set status='active' where id='" + Session["id"].ToString() + "'", con1);
                //cmd1.ExecuteNonQuery();
                //MailMessage msg = new MailMessage(new MailAddress("noreplymailing22@gmail.com"), new MailAddress(Session["emailid"].ToString()));
                //msg.Subject = "Your Login Password and Eligible to Attend Interview.... Check it..";
                //msg.IsBodyHtml = true;
                //msg.Body = "Username: " + Session["username"].ToString() + "<br/>" + "Password: " + Session["password"].ToString();
                //System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("noreplymailing22@gmail.com", "ipudbyifzmcsjyhk");
                //SmtpClient smclient = new SmtpClient();
                //smclient.EnableSsl = true;
                //smclient.UseDefaultCredentials = false;
                //smclient.Credentials = nwcred;
                //smclient.Host = "smtp.gmail.com";
                //smclient.Port = 587;
                //smclient.Send(msg);
                //ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Login is Activated Successfully and Send Mail!!!');</script>");
                bin();
            }
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
        string path = "D:\\dotnetprojects\\INTERVIEWFORUM\\TFILES\\" +DropDownList1.SelectedItem.Text;
        if (!string.IsNullOrEmpty(path))
        {
            string[] readText = File.ReadAllLines(path);
            StringBuilder strbuild = new StringBuilder();
            foreach (string s in readText)
            {
                strbuild.Append(s);
                strbuild.AppendLine();
            }
            TextBox3.Text = strbuild.ToString();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

                 MailMessage msg = new MailMessage(new MailAddress("noreplymailing22@gmail.com"), new MailAddress(TextBox2.Text));
                   msg.Subject = " Hai   " + TextBox1.Text;
                   msg.IsBodyHtml = true;
                   var body = new StringBuilder();
                  body.AppendFormat("<b>Welcome to  Interview Forum Test!</b>");
                body.AppendLine("<br />");
                body.AppendLine("<br />");
                body.AppendLine(@"This message serves as confirmation that you are now successfully registered with InterView Test.");
                body.AppendLine("<br />");
                body.AppendLine(@"Use below link to Attend Your Online Editor Test.");
                body.AppendLine("<br />");
                body.AppendLine(" <a href='http://localhost:63077/INTERVIEWFORUM/editorforum.aspx?email=" + TextBox2.Text + " '>Run Test</a>");
               body.AppendLine("<br />");
                body.AppendLine("<br />");
                body.AppendLine(@"Thank you,");
                body.AppendLine("<br />");
                body.AppendLine("<br />");
                body.AppendLine(@"<b>Online Interview Forum.</b>");
                msg.Body = body.ToString();
                System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("noreplymailing22@gmail.com", "ipudbyifzmcsjyhk");
                SmtpClient smclient = new SmtpClient();
                smclient.EnableSsl = true;
                smclient.UseDefaultCredentials = false;
                smclient.Credentials = nwcred;
                smclient.Host = "smtp.gmail.com";
                smclient.Port = 587;
                smclient.Send(msg);
        Class1 getcon1 = new Class1();
        SqlConnection con1 = getcon1.connect();
        SqlCommand cmd = new SqlCommand("insert into editortask values('" + Session["id"].ToString() + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + DropDownList1.SelectedItem.Text + "','" + TextBox3.Text + "','" + DateTime.Now.ToString() + "','started','null','null')", con1);
        cmd.ExecuteNonQuery();
       // ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Mobile number verified successfully, Kindly check your email for Email verification');</script>");
               
    
                //.Visible = true;
                //Label1.Text = "Mobile No Verified And Check Your Mail For Mail Verification";
                // ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Mobile number verified successfully, Kindly check your email for Email verification');</script>");
               

        //Class1 getcon1 = new Class1();
        //SqlConnection con1 = getcon1.connect();
        //SqlCommand cmd1 = new SqlCommand("update candidatereg set status='active' where id='" + Session["id"].ToString() + "'", con1);
        //cmd1.ExecuteNonQuery();
        //MailMessage msg = new MailMessage(new MailAddress("noreplymailing22@gmail.com"), new MailAddress(Session["emailid"].ToString()));
        //msg.Subject = "Your Login Password and Eligible to Attend Interview.... Check it..";
        //msg.IsBodyHtml = true;
        //msg.Body = "Username: " + Session["username"].ToString() + "<br/>" + "Password: " + Session["password"].ToString();
        //System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("noreplymailing22@gmail.com", "ipudbyifzmcsjyhk");
        //SmtpClient smclient = new SmtpClient();
        //smclient.EnableSsl = true;
        //smclient.UseDefaultCredentials = false;
        //smclient.Credentials = nwcred;
        //smclient.Host = "smtp.gmail.com";
        //smclient.Port = 587;
        //smclient.Send(msg);
        ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('Mail Send Successfully !');</script>");
             

    }
}
