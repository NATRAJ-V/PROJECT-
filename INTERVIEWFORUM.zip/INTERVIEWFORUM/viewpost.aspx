﻿<%@ Page Language="C#" MasterPageFile="~/admin.master" AutoEventWireup="true" CodeFile="viewpost.aspx.cs" Inherits="viewpost" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
<script language="javascript" type="text/javascript">
     function accept(id)
    {
    location.href='viewpost.aspx?id='+id;
    }
       </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
<div id = "dvGrid" style ="padding:10px;width:100%; overflow:scroll; height:100%">
  <asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" 
            OnPageIndexChanging="GridView1_PageIndexChanging" AllowPaging="True" 
             PageSize="5" onselectedindexchanged="GridView1_SelectedIndexChanged1" 
              Height="98px" Font-Bold="True"  HorizontalAlign="Center" CellPadding="4" style="width:933px;" 
                ForeColor="Black" BackColor="#CCCCCC" BorderColor="#999999" 
             BorderStyle="Solid" BorderWidth="3px" CellSpacing="2">
            <RowStyle HorizontalAlign="Center" BackColor="White"/>
                <Columns>
                  <asp:BoundField DataField="id" HeaderText="Sno" />
                  <asp:BoundField DataField="postname" HeaderText="Post Name"/>
                  <asp:BoundField DataField="domainname" HeaderText="Domain"/>
                  <asp:BoundField DataField="qualification" HeaderText="Qualification"/>
                  <asp:BoundField DataField="expfresher" HeaderText="Exp/Fresher"/>
                  <asp:BoundField DataField="keyskills" HeaderText="Key Skills"/>
                  <asp:BoundField DataField="interviewdate" HeaderText="Interview Date"/>
                  <asp:BoundField DataField="salary" HeaderText="Salary"/>
                  <asp:TemplateField HeaderText="">
                  <ItemTemplate>
                    <a href="javascript:accept('<%# DataBinder.Eval(Container.DataItem,"id")%>')" >
                    <h3 style="color:black">
                        Delete</h3></a>
                      </ItemTemplate>
                  </asp:TemplateField>
                 </Columns>
            <FooterStyle BackColor="#CCCCCC" />
            <PagerStyle ForeColor="Black" HorizontalAlign="Left" BackColor="#CCCCCC" />
            <SelectedRowStyle BorderColor="Orange" BackColor="#000099" Font-Bold="True" 
                 ForeColor="White"  />
            <HeaderStyle BorderColor="Orange"  HorizontalAlign="Center" BackColor="Black" 
                Font-Bold="True" ForeColor="White" />
        </asp:GridView> 
        </div>
</asp:Content>

