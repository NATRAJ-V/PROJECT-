﻿<%@ Page Language="C#" MasterPageFile="~/home.master" AutoEventWireup="true" CodeFile="admin.aspx.cs" Inherits="admin" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
<style type="text/css">
*,
*:before,
*:after {
   box-sizing: border-box;
}
fieldset {
 border: 1px solid #c6c7cc;
  border-radius: 6px;
  margin: 0;
  padding: 0;
}
 .btn {
  background: linear-gradient(white, white);
  border:1;
  color:Blue;
  cursor: pointer;
  font-weight: bold;
  float:none;
  padding: 8px 16px;
  align:center;
}
</style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
<fieldset style="width:300px;">
        <legend style="color:Blue; font-size:15px;">Login</legend>
       
           <table class="style2" style="color:Black; font-size:15px; padding:1 1 2 2">
             <tr>
             <td class="style1">
           Username:  </td>
             <td>
            <asp:TextBox ID="TextBox1" runat="server"></asp:TextBox> </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" 
                    ErrorMessage="*" ControlToValidate="TextBox1"></asp:RequiredFieldValidator>
            </td>
             </tr>
            
             <tr>
             <td class="style1">
           Password:</td>
             <td>
            <asp:TextBox ID="TextBox2" runat="server" TextMode="Password"></asp:TextBox></td>
             <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator4" runat="server" 
                    ErrorMessage="*" ControlToValidate="TextBox2"></asp:RequiredFieldValidator>
            </td>
             </tr>
            
            
             </table>
       
          </fieldset>
          <fieldset style="width:300px;" align="center">
       
            <asp:Button ID="Button1" runat="server" Text="Submit" BackColor="White" 
                  ForeColor="Blue" CssClass="btn" onclick="Button1_Click"/>
       
        </fieldset>
        <br /> <br />
         <br /> <br />
         <br /> <br />
         <br /> <br />
         <br /> <br />
          <br /> <br />
</asp:Content>

