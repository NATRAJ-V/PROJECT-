﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Net;
using System.Net.Mail;
public partial class attendtask : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session["Timer"] = DateTime.Now.AddMinutes(10).ToString();
        }
    }
    protected void timertest_tick(object sen, EventArgs e)
    {
        if (DateTime.Compare(DateTime.Now, DateTime.Parse(Session["Timer"].ToString())) < 0)
        {
            litmsg.Text = "Time Left:" + (((Int32)DateTime.Parse(Session["Timer"].ToString()).Subtract(DateTime.Now).TotalMinutes).ToString() + "Minute" + ((Int32)DateTime.Parse(Session["Timer"].ToString()).Subtract(DateTime.Now).TotalSeconds) % 60).ToString() + "seconds";

        }
        else
        {
            litmsg.Text = "Timer Expired";
            Response.Redirect("candidatelogin.aspx");
        }
    }
    
    public void display()
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("SELECT * FROM candidatereg WHERE username='" + Session["username"].ToString() + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Session["username"] = dr["username"].ToString();
            Session["postname"] = dr["postname"].ToString();
            Session["emailid"] = dr["emailid"].ToString();
            Session["phoneno"] = dr["phoneno"].ToString();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string aa1 = "_" + Session["username"].ToString() + "_" + DropDownList2.SelectedItem.Text + ".txt";
        string fileName = @"E:\dotnetprojects\INTERVIEWFORUM\taskans\" + aa1;
        using (StreamWriter sw = File.CreateText(fileName))
        {
            sw.Write(TextBox2.Text);
        }
        display();
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("insert into firsttask values('" + Session["username"].ToString() + "','" + Session["postname"].ToString() + "','" + Session["e-mailid"].ToString() + "','" + Session["phoneno"].ToString() + "','" + aa1 + "','" + DropDownList2.SelectedItem.Text + "','" + DateTime.Now.ToString("dd/MM/yyyy") + "','completed','" + Session["taskid"].ToString() + "')", con);
        cmd.ExecuteNonQuery();
        MailMessage msg = new MailMessage(new MailAddress("noreplymailing22@gmail.com"), new MailAddress(Session["e-mailid"].ToString()));
        msg.Subject = "Interview First Task";
        msg.IsBodyHtml = true;
        msg.Body = "Username:-" + Session["username"].ToString() + "<br/>" + "Post Name:-" + Session["postname"].ToString() + "<br/>" + "Result Shown Below";
        msg.Attachments.Add(new Attachment(fileName));
        System.Net.NetworkCredential nwcred = new System.Net.NetworkCredential("noreplymailing22@gmail.com", "ipudbyifzmcsjyhk");
        SmtpClient smclient = new SmtpClient();
        smclient.EnableSsl = true;
        smclient.UseDefaultCredentials = false;
        smclient.Credentials = nwcred;
        smclient.Host = "smtp.gmail.com";
        smclient.Port = 587;
        smclient.Send(msg);
        ClientScript.RegisterStartupScript(this.GetType(), "ele", "<script>alert('All Task Over!!Wait for Your Result!!');</script>");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Class1 getcon = new Class1();
        SqlConnection con = getcon.connect();
        SqlCommand cmd = new SqlCommand("SELECT uploadtask,id FROM firsttaskques WHERE domainname='" + DropDownList2.SelectedItem.Text + "' ORDER BY NEWID()", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Session["taskid"] = dr["id"].ToString();
            string path = "E:\\dotnetprojects\\INTERVIEWFORUM\\questions\\" + dr["uploadtask"].ToString();
            if (!string.IsNullOrEmpty(path))
            {
                string[] readText = File.ReadAllLines(path);
                StringBuilder strbuild = new StringBuilder();
                foreach (string s in readText)
                {
                    strbuild.Append(s);
                    strbuild.AppendLine();
                }
                TextBox2.Text = strbuild.ToString();
            }
        }
    }
}
