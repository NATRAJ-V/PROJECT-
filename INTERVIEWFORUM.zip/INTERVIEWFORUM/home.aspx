﻿<%@ Page Language="C#" MasterPageFile="~/home.master" AutoEventWireup="true" CodeFile="home.aspx.cs" Inherits="home" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">

<p align="justify" style="color:#007FFF; font-size:16px;">
Online Interview And Job Selection Using Online Editor is an online research method conducted using computer-mediated communication system. The online interview requires different ethical considerations process. The system is an online application that can be accessed throughout the organization and it manages the candidate registration to the selection process. In the previous system it arises more difficult and not have known about the organization and current job openings. In addition, finding the right candidate with desired qualifications to fill their current job openings is an important task for the recruiters of any organization. The Online Interview And Job Selection Using Online Editor is the solution where recruiter, as well as the job seeker, meets aiming at fulfilling their individual requirement. Admin will post the job recruitment details. It is displayed in the search portal bar of the candidate. The candidate has knowledge related to the recruitment means then register in the organization. The admin views the register candidate details and sends approval based on the post of the job. The candidate will receive notification about the interview. Next process, the candidate has to log in and attend the online test. The online test has two categories of task questions. The first task of the interview question displayed based on random generation algorithm. The candidate has to finish the task within the time limited. Suppose it exists the limit means the process will come out of the login. The cloud migration algorithm is implemented on displaying completed candidate task result to admin. The result is generated in doc format. The random generation algorithm is used to generate second task interview questions. The question is displayed randomly and candidate completed result is sent to admin in PDF format. The recruitment process is sped up at every stage from job postings to receiving applications from candidates, interviewing process.

</p>
</asp:Content>

