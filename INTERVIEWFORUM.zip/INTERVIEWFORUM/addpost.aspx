﻿<%@ Page Language="C#" MasterPageFile="~/admin.master" AutoEventWireup="true" CodeFile="addpost.aspx.cs" Inherits="addpost" Title="Untitled Page" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
    <style type="text/css">
*,
*:before,
*:after {
   box-sizing: border-box;
}
fieldset {
 border: 1px solid #c6c7cc;
  border-radius: 6px;
  margin: 0;
  padding: 0;
}
 .btn {
  background: linear-gradient(white, white);
  border:1;
  color:Blue;
  cursor: pointer;
  font-weight: bold;
  float:none;
  padding: 8px 16px;
  align:center;
}
</style>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/ui-lightness/jquery-ui.css">
<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.js"></script>
<script type="text/javascript" src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script type="text/javascript">
    $(function() {
    $("#TextBox4").datepicker();
    });
</script>
<style type="text/css">
.ui-datepicker { font-size:10pt !important}
</style>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
    <fieldset style="width:300px;">
        <legend style="color:Blue; font-size:15px;">Post Details</legend>
           <table style="color:Black; font-size:15px; padding:1 1 2 2">
             <tr>
             <td>
           Post Name:  </td>
             <td>
            <asp:TextBox ID="TextBox1" runat="server" ValidationGroup="admin"></asp:TextBox> </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" 
                    ErrorMessage="*" ControlToValidate="TextBox1" ValidationGroup="admin"></asp:RequiredFieldValidator>
            </td>
             </tr>
             <tr>
             <td>
          Domain Name:  </td>
             <td>
            
                 <asp:DropDownList ID="DropDownList2" runat="server">
                     <asp:ListItem>--Select--</asp:ListItem>
                     <asp:ListItem>ASP.NET</asp:ListItem>
                     <asp:ListItem>PHP</asp:ListItem>
                     <asp:ListItem>WORDPRESS</asp:ListItem>
                     <asp:ListItem>ANDROID</asp:ListItem>
                 </asp:DropDownList>
                 </td>
             </tr>
              <tr>
             <td>
          Qualification:  </td>
             <td>
            <asp:TextBox ID="TextBox2" runat="server" ValidationGroup="admin"></asp:TextBox> </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator5" runat="server" 
                    ErrorMessage="*" ControlToValidate="TextBox2" ValidationGroup="admin"></asp:RequiredFieldValidator>
            </td>
             </tr>
            
               <tr>
             <td>
          Experience/Fresher:  </td>
             <td>
                 <asp:DropDownList ID="DropDownList1" runat="server" ValidationGroup="admin" Height="40%">
                 <asp:ListItem Text="Experience/Fresher"></asp:ListItem>
                 <asp:ListItem Text="Experience"></asp:ListItem>
                 <asp:ListItem Text="Fresher"></asp:ListItem>
                 </asp:DropDownList>
           </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator7" runat="server" 
                    ErrorMessage="*" ControlToValidate="DropDownList1" ValidationGroup="admin"></asp:RequiredFieldValidator>
            </td>
             </tr>
              <tr>
             <td>
         Key Skills:  </td>
             <td>
            <asp:TextBox ID="TextBox3" runat="server" ValidationGroup="admin" TextMode="MultiLine"></asp:TextBox> </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator8" runat="server" 
                    ErrorMessage="*" ControlToValidate="TextBox3" ValidationGroup="admin"></asp:RequiredFieldValidator>
            </td>
             </tr>
               <tr>
             <td>
          Interview Date:  </td>
             <td>
            <asp:TextBox ID="TextBox4" runat="server"   
             ValidationGroup="admin"></asp:TextBox> </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" 
                    ErrorMessage="*" ControlToValidate="TextBox4" ValidationGroup="admin"></asp:RequiredFieldValidator>
            </td>
             </tr>
            <tr>
             <td>
          Salary:  </td>
             <td>
            <asp:TextBox ID="TextBox5" runat="server" ValidationGroup="admin"></asp:TextBox> </td>
            <td>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" 
                    ErrorMessage="*" ControlToValidate="TextBox5" ValidationGroup="admin"></asp:RequiredFieldValidator>
            </td>
             </tr>
            
             </table>
          </fieldset>
          <fieldset style="width:300px;">
            <asp:Button ID="Button1" runat="server" Text="Upload" BackColor="White" 
                  ForeColor="Blue" CssClass="btn" onclick="Button1_Click"/>
                   <asp:Button ID="Button2" runat="server" Text="View Post" BackColor="White" 
                  ForeColor="Blue" CssClass="btn" onclick="Button2_Click"/>
        </fieldset>
        <br /> <br />
         <br /> <br />
         <br /> <br />
         <br /> <br />
         <br /> <br />
          <br /> <br />
</asp:Content>

